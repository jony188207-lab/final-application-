// Firestore Security Rules tests. These need the Firestore emulator, so they only run via
//   npm run test:rules
// (which wraps vitest in `firebase emulators:exec`). Without the emulator they are skipped.
import { readFileSync } from "node:fs";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from "@firebase/rules-unit-testing";

const run = Boolean(process.env.FIRESTORE_EMULATOR_HOST);

describe.skipIf(!run)("firestore.rules", () => {
  let env: RulesTestEnvironment;
  beforeAll(async () => {
    env = await initializeTestEnvironment({ projectId: "rentflow-rules-test", firestore: { rules: readFileSync("firestore.rules", "utf8") } });
    await env.withSecurityRulesDisabled(async (ctx) => {
      const d = ctx.firestore();
      const { doc, setDoc } = await import("firebase/firestore");
      await setDoc(doc(d, "publicSettings/pricing"), { totalFeeCents: 3500 });
      for (const p of ["applications/a1", "payments/p1", "screeningReports/r1", "auditLogs/l1", "admins/adminUid", "settings/app", "notifications/n1", "adminSecrets/adminUid"]) {
        await setDoc(doc(d, p), { x: 1 });
      }
    });
  });
  afterAll(async () => env?.cleanup());

  const readable = async (ctx: ReturnType<RulesTestEnvironment["unauthenticatedContext"]>, path: string) => {
    const { doc, getDoc } = await import("firebase/firestore");
    return getDoc(doc(ctx.firestore(), path));
  };
  const writable = async (ctx: ReturnType<RulesTestEnvironment["unauthenticatedContext"]>, path: string) => {
    const { doc, setDoc } = await import("firebase/firestore");
    return setDoc(doc(ctx.firestore(), path), { x: 2 });
  };

  const PRIVATE = ["applications/a1", "payments/p1", "screeningReports/r1", "auditLogs/l1", "admins/adminUid", "settings/app", "notifications/n1", "adminSecrets/adminUid"];

  it("lets anyone read the public pricing, but nobody write it", async () => {
    const anon = env.unauthenticatedContext();
    await assertSucceeds(readable(anon, "publicSettings/pricing"));
    await assertFails(writable(anon, "publicSettings/pricing"));
    await assertFails(writable(env.authenticatedContext("adminUid", { email_verified: true }), "publicSettings/pricing"));
  });

  it.each(PRIVATE)("denies anonymous, applicant, and even admin-looking users on %s", async (path) => {
    for (const ctx of [env.unauthenticatedContext(), env.authenticatedContext("applicant1"), env.authenticatedContext("adminUid", { email_verified: true, admin: true })]) {
      await assertFails(readable(ctx, path));
      await assertFails(writable(ctx, path));
    }
  });

  it("denies deleting or editing audit records from a client", async () => {
    const ctx = env.authenticatedContext("adminUid", { email_verified: true });
    const { doc, deleteDoc, updateDoc } = await import("firebase/firestore");
    await assertFails(deleteDoc(doc(ctx.firestore(), "auditLogs/l1")));
    await assertFails(updateDoc(doc(ctx.firestore(), "auditLogs/l1"), { action: "tampered" }));
  });
});
