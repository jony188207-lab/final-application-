import { randomBytes } from "node:crypto";

// Test-only values. Nothing here is a real credential.
process.env.INITIAL_ADMIN_EMAIL = "owner@example.com";
process.env.DATA_ENCRYPTION_KEY = randomBytes(32).toString("base64");
process.env.PROTECTED_AREA_SECRET = "test-protected-secret";
process.env.NEXT_PUBLIC_FIREBASE_API_KEY = "test-api-key";
process.env.PAYMENT_WEBHOOK_SECRET = "test-webhook-secret";
process.env.PAYMENTS_MODE = "test";
