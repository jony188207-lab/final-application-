// Main App ZIP: the applicant-facing QR image route streams only while a method is enabled.
import { beforeEach, describe, expect, it, vi } from "vitest";
import { db, fakeAuth, req } from "./helpers/fake-firestore";

const { files } = vi.hoisted(() => ({ files: new Map<string, Buffer>() }));
vi.mock("@/lib/firebase/admin", () => ({ adminDb: () => db, adminAuth: () => fakeAuth }));
vi.mock("@/lib/storage", () => ({
  putPrivate: async (p: string, b: Buffer) => { files.set(p, b); },
  readPrivate: async (p: string) => { const b = files.get(p); if (!b) throw new Error("missing"); return b; },
  deletePrivate: async (p: string) => { files.delete(p); },
}));

import { GET as publicQr } from "@/app/api/public/payment-methods/[id]/qr/route";

const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(32)]);
const method = { provider: "cashapp", enabled: true, displayName: "Cash App", hasQr: true, qrPath: "qr/m1.png", qrContentType: "image/png", currency: "USD" };

beforeEach(() => { db.reset(); files.clear(); files.set("qr/m1.png", PNG); });

describe("public QR route", () => {
  it("serves the image for an enabled method with correct headers", async () => {
    db.store.set("paymentMethods/m1", method);
    const res = await publicQr(req("/api/public/payment-methods/m1/qr"), { params: { id: "m1" } });
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toBe("image/png");
    expect(res.headers.get("x-content-type-options")).toBe("nosniff");
  });
  it("returns 404 when the method is disabled, has no QR, or does not exist", async () => {
    db.store.set("paymentMethods/m1", { ...method, enabled: false });
    expect((await publicQr(req("/api/public/payment-methods/m1/qr"), { params: { id: "m1" } })).status).toBe(404);
    db.store.set("paymentMethods/m2", { ...method, hasQr: false });
    expect((await publicQr(req("/api/public/payment-methods/m2/qr"), { params: { id: "m2" } })).status).toBe(404);
    expect((await publicQr(req("/api/public/payment-methods/none/qr"), { params: { id: "none" } })).status).toBe(404);
  });
});
