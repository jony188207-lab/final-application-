// Shared (client + server) validation for the rental application. The server re-validates everything.
import { z } from "zod";

const text = (max: number) => z.string().trim().min(1).max(max);
const optText = (max: number) => z.string().trim().max(max).optional().or(z.literal("").transform(() => undefined));
const isoMonthOrDate = z.string().regex(/^\d{4}-\d{2}(-\d{2})?$/, "Use YYYY-MM or YYYY-MM-DD");

export const ApplicationInput = z.object({
  paymentId: z.string().min(5).max(160),
  fullName: text(100),
  phone: z.string().trim().regex(/^[0-9+()\-.\s]{7,20}$/, "Enter a valid phone number"),
  property: z.object({
    address: text(200),
    rentCents: z.number().int().min(0).max(10_000_000),
    moveIn: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD"),
  }),
  household: z.object({
    adults: z.number().int().min(1).max(10),
    children: z.number().int().min(0).max(10),
    pets: z.array(z.object({ type: text(40), breed: optText(60) })).max(5),
  }),
  employment: z.object({
    employer: text(120),
    title: text(100),
    monthlyIncomeCents: z.number().int().min(0).max(100_000_000),
    startDate: isoMonthOrDate.optional().or(z.literal("").transform(() => undefined)),
  }),
  rentalHistory: z
    .array(
      z.object({
        address: text(200),
        landlord: optText(100),
        from: isoMonthOrDate,
        to: isoMonthOrDate.optional().or(z.literal("").transform(() => undefined)),
        rentCents: z.number().int().min(0).max(10_000_000).optional(),
        reason: optText(200),
      }),
    )
    .max(5),
  // Optional: collect only if your screening provider requires it. Stored encrypted, shown only in Protected information.
  ssn: z.string().trim().regex(/^\d{3}-?\d{2}-?\d{4}$/, "Enter a valid SSN").optional().or(z.literal("").transform(() => undefined)),
  consent: z.object({
    fcraDisclosure: z.literal(true, { errorMap: () => ({ message: "You must acknowledge the disclosure" }) }),
    screeningAuthorization: z.literal(true, { errorMap: () => ({ message: "You must authorize screening to apply" }) }),
  }),
});
export type ApplicationInput = z.infer<typeof ApplicationInput>;
