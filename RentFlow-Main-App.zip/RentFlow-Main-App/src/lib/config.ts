// Runtime settings stored in Firestore (server-only collection `settings`).
import { adminDb } from "@/lib/firebase/admin";
import { DEFAULT_LOCKOUT, type LockoutConfig } from "@/lib/auth/protected-area";
import { DEFAULT_FEE_CENTS } from "@/lib/settings";

export interface AppSettings {
  totalFeeCents: number;
  baseCurrency: string; // ISO 4217, e.g. "USD"
  applicationsEnabled: boolean;
  requireScreenshot: boolean;
  consentVersion: string;
  paymentProvider: "mock" | "stripe";
}

export interface SecuritySettings {
  maxFailedAttempts: number;
  lockoutMinutes: number;
}

export const DEFAULT_APP_SETTINGS: AppSettings = {
  totalFeeCents: DEFAULT_FEE_CENTS,
  baseCurrency: "USD",
  applicationsEnabled: true,
  requireScreenshot: true,
  consentVersion: "v1",
  paymentProvider: "mock",
};

export const DEFAULT_SECURITY_SETTINGS: SecuritySettings = { maxFailedAttempts: 3, lockoutMinutes: 15 };

export async function getAppSettings(): Promise<AppSettings> {
  const d = (await adminDb().collection("settings").doc("app").get()).data();
  return { ...DEFAULT_APP_SETTINGS, ...(d as Partial<AppSettings> | undefined) };
}

export async function getSecuritySettings(): Promise<SecuritySettings> {
  const d = (await adminDb().collection("settings").doc("security").get()).data();
  return { ...DEFAULT_SECURITY_SETTINGS, ...(d as Partial<SecuritySettings> | undefined) };
}

export const toLockoutConfig = (s: SecuritySettings): LockoutConfig => ({
  maxFailedAttempts: s.maxFailedAttempts,
  lockoutMs: s.lockoutMinutes * 60_000,
});

export { DEFAULT_LOCKOUT };

/** Which integrations are configured (booleans only; values are NEVER returned). */
export function configurationStatus() {
  const set = (n: string) => Boolean(process.env[n]);
  return {
    firebaseAdmin: set("FIREBASE_ADMIN_PROJECT_ID") && set("FIREBASE_ADMIN_CLIENT_EMAIL") && set("FIREBASE_ADMIN_PRIVATE_KEY"),
    initialAdminEmail: set("INITIAL_ADMIN_EMAIL"),
    dataEncryptionKey: set("DATA_ENCRYPTION_KEY"),
    protectedAreaSecret: set("PROTECTED_AREA_SECRET"),
    payments: {
      mode: process.env.PAYMENTS_MODE === "live" ? "live" : "test",
      liveEnabled: process.env.PAYMENTS_LIVE_ENABLED === "true" && process.env.PAYMENTS_MODE === "live",
      provider: process.env.PAYMENT_PROVIDER ?? "mock",
      webhookSecret: set("PAYMENT_WEBHOOK_SECRET"),
    },
    screening: {
      provider: process.env.SCREENING_PROVIDER ?? "mock",
      apiBaseUrl: set("SCREENING_API_BASE_URL"),
      apiKey: set("SCREENING_API_KEY"),
    },
    email: { provider: process.env.EMAIL_PROVIDER ?? "console", from: set("EMAIL_FROM") },
  };
}
