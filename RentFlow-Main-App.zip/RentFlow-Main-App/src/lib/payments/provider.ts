// Payment provider interface. Card data never reaches this app: the provider's hosted checkout
// collects it, and we receive only a provider reference, status, amount, brand and last four digits.
import { adminDb } from "@/lib/firebase/admin";
import { serverEnv } from "@/lib/env";
import { HttpError } from "@/lib/http";
import type { PaymentStatus } from "@/lib/domain";

export interface ProviderPayment {
  providerRef: string;
  status: PaymentStatus;
  amountCents: number;
  currency: string;
  cardBrand?: string;
  cardLast4?: string;
}

export interface RefundResult {
  refundRef: string;
  status: "succeeded" | "pending" | "failed";
}

export interface PaymentProvider {
  readonly name: string;
  /** Authoritative lookup from the provider (server-to-server). */
  fetchPayment(providerRef: string): Promise<ProviderPayment | null>;
  refund?(providerRef: string, amountCents: number): Promise<RefundResult>;
}

/**
 * TEST-MODE provider. Its "provider side" is a Firestore ledger (`mockProviderLedger`) that only
 * the seed script / webhook simulator writes. It is refused outright when payments mode is live.
 */
class MockProvider implements PaymentProvider {
  readonly name = "mock";
  async fetchPayment(providerRef: string): Promise<ProviderPayment | null> {
    const d = (await adminDb().collection("mockProviderLedger").doc(providerRef).get()).data();
    return d ? ({ providerRef, ...d } as ProviderPayment) : null;
  }
  async refund(providerRef: string): Promise<RefundResult> {
    return { refundRef: `mock_re_${providerRef}`, status: "succeeded" };
  }
}

/** Placeholder for a real provider adapter. Requires your own merchant account and credentials. */
class UnconfiguredProvider implements PaymentProvider {
  constructor(readonly name: string) {}
  async fetchPayment(): Promise<ProviderPayment | null> {
    throw new HttpError(501, `Payment provider "${this.name}" is not connected. Implement its adapter in src/lib/payments/.`);
  }
}

export function getPaymentProvider(): PaymentProvider {
  const name = process.env.PAYMENT_PROVIDER ?? "mock";
  if (serverEnv.paymentsMode === "live") {
    if (!serverEnv.livePaymentsAllowed) throw new HttpError(503, "Live payments are disabled.");
    if (name === "mock") throw new HttpError(503, "The mock provider cannot be used in live mode.");
  }
  return name === "mock" ? new MockProvider() : new UnconfiguredProvider(name);
}
