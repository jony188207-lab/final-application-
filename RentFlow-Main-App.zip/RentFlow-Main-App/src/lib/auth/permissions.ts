// Role → permission matrix. Pure, so it is unit-tested and shared by every API route.
import type { AdminRole } from "./authorize";

export type Permission =
  | "applications.read"
  | "applications.update"
  | "applications.reject"
  | "applications.export"
  | "payments.read"
  | "payments.manage"
  | "paymentMethods.manage"
  | "screening.read"
  | "screening.manage"
  | "notifications.read"
  | "settings.read"
  | "settings.write"
  | "audit.read"
  | "admins.manage"
  | "protected.view";

const VIEWER: Permission[] = ["applications.read", "payments.read", "screening.read", "notifications.read"];
const REVIEWER: Permission[] = [...VIEWER, "applications.update", "applications.reject", "screening.manage", "settings.read"];
const ADMIN: Permission[] = [...REVIEWER, "applications.export", "payments.manage", "settings.write", "audit.read"];
// Changing WHERE applicants send money is the highest-risk setting: super_admin only.
const SUPER: Permission[] = [...ADMIN, "admins.manage", "paymentMethods.manage"];

const MATRIX: Record<AdminRole, Permission[]> = {
  viewer: VIEWER,
  reviewer: REVIEWER,
  admin: ADMIN,
  super_admin: SUPER,
};

export interface PermissionSubject {
  role: AdminRole;
  /** Explicit per-admin grant. No role (not even super_admin) implies it. */
  canViewProtected?: boolean;
}

export function can(subject: PermissionSubject, permission: Permission): boolean {
  if (permission === "protected.view") {
    return subject.canViewProtected === true && MATRIX[subject.role].includes("applications.update");
  }
  return MATRIX[subject.role].includes(permission);
}
