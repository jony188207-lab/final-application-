// Payment-method definitions and validation. Pure (no I/O).
//
// IMPORTANT: PROVIDER_CAPABILITIES records what each provider is expected to support for receiving a
// payment, so the admin UI/server never offers a feature the provider doesn't have. These entries are
// best-effort and MUST be checked against each provider's current documentation and your own account
// type before going live. Manual methods (everything except a real integration) are verified by an
// admin reading the applicant's transaction reference + screenshot; they are never auto-confirmed.
import { z } from "zod";

export const PROVIDERS = ["stripe", "cashapp", "payoneer", "paypal", "chime", "custom"] as const;
export type ProviderId = (typeof PROVIDERS)[number];

interface Capability {
  label: string;
  supportsUrl: boolean;
  /** Allowed hostnames (exact or subdomain). null = any https host (custom only). */
  urlHosts: string[] | null;
  supportsQr: boolean;
  identifierLabel: string | null; // null = no identifier concept
  identifierPattern?: RegExp;
  identifierHint?: string;
  note: string;
}

export const PROVIDER_CAPABILITIES: Record<ProviderId, Capability> = {
  stripe: {
    label: "Stripe",
    supportsUrl: true,
    urlHosts: ["buy.stripe.com", "checkout.stripe.com"],
    supportsQr: true,
    identifierLabel: null,
    note: "Use a Stripe Payment Link you created. Payments made through the link are NOT confirmed automatically by RentFlow; an admin verifies them (an automatic Stripe webhook adapter is not built yet).",
  },
  cashapp: {
    label: "Cash App",
    supportsUrl: true,
    urlHosts: ["cash.app"],
    supportsQr: true,
    identifierLabel: "$Cashtag",
    identifierPattern: /^\$[A-Za-z][A-Za-z0-9_]{1,19}$/,
    identifierHint: "Example: $YourBusiness",
    note: "Link format is https://cash.app/$cashtag. Cash App Pay does not notify RentFlow; payments are verified by an admin.",
  },
  payoneer: {
    label: "Payoneer",
    supportsUrl: true,
    urlHosts: ["payoneer.com"],
    supportsQr: false,
    identifierLabel: "Payoneer account email or ID (shown to applicants)",
    identifierPattern: /^[^\s]{3,100}$/,
    identifierHint: "The account detail your applicants should send to",
    note: "Only a Payoneer-generated payment-request link is accepted. Payoneer is not known to offer a native QR code, so QR upload is disabled.",
  },
  paypal: {
    label: "PayPal",
    supportsUrl: true,
    urlHosts: ["paypal.me", "paypal.com"],
    supportsQr: true,
    identifierLabel: "PayPal email or paypal.me name",
    identifierPattern: /^[^\s]{3,100}$/,
    identifierHint: "Example: payments@yourcompany.com",
    note: "Use a paypal.me link or a PayPal-generated link. PayPal does not notify RentFlow; payments are verified by an admin.",
  },
  chime: {
    label: "Chime",
    supportsUrl: false,
    urlHosts: [],
    supportsQr: false,
    identifierLabel: "$ChimeSign",
    identifierPattern: /^\$[A-Za-z0-9_-]{2,30}$/,
    identifierHint: "Example: $yourchimesign",
    note: "Chime is not known to provide public payment links or QR codes, so only a $ChimeSign identifier and instructions can be shown.",
  },
  custom: {
    label: "Custom method",
    supportsUrl: true,
    urlHosts: null,
    supportsQr: true,
    identifierLabel: "Account / payment identifier",
    identifierPattern: /^.{1,100}$/,
    note: "You are responsible for the accuracy of what you enter. Only https links are accepted.",
  },
};

const hostMatches = (host: string, allowed: string[]) => allowed.some((h) => host === h || host.endsWith(`.${h}`));

const emptyToUndef = (v: unknown) => (typeof v === "string" && v.trim() === "" ? undefined : v);

export const PaymentMethodInput = z
  .object({
    provider: z.enum(PROVIDERS),
    enabled: z.boolean(),
    displayName: z.string().trim().min(1).max(60),
    description: z.string().trim().max(500).default(""),
    instructions: z.string().trim().max(2000).default(""),
    applicantGuidance: z.string().trim().max(1000).default(""),
    paymentUrl: z.preprocess(emptyToUndef, z.string().trim().max(500).optional()),
    identifier: z.preprocess(emptyToUndef, z.string().trim().max(100).optional()),
    amountMode: z.enum(["global", "fixed"]).default("global"),
    fixedAmountCents: z.number().int().min(1).max(5_000_000).optional(),
    currency: z.string().regex(/^[A-Z]{3}$/).default("USD"),
    displayOrder: z.number().int().min(0).max(1000).default(100),
    countries: z.array(z.string().regex(/^[A-Z]{2}$/)).max(250).default([]),
  })
  .superRefine((m, ctx) => {
    const cap = PROVIDER_CAPABILITIES[m.provider];
    const bad = (path: string, message: string) => ctx.addIssue({ code: "custom", path: [path], message });

    if (m.paymentUrl) {
      if (!cap.supportsUrl) bad("paymentUrl", `${cap.label} does not support payment links`);
      else {
        let u: URL | null = null;
        try { u = new URL(m.paymentUrl); } catch { /* handled below */ }
        if (!u || u.protocol !== "https:") bad("paymentUrl", "Payment URL must be a valid https link");
        else if (u.username || u.password) bad("paymentUrl", "Payment URL must not contain credentials");
        else if (cap.urlHosts && !hostMatches(u.hostname.toLowerCase(), cap.urlHosts))
          bad("paymentUrl", `${cap.label} links must be on: ${cap.urlHosts.join(", ")}`);
      }
    }
    if (m.identifier) {
      if (!cap.identifierLabel) bad("identifier", `${cap.label} does not use an account identifier`);
      else if (cap.identifierPattern && !cap.identifierPattern.test(m.identifier))
        bad("identifier", `Invalid ${cap.identifierLabel}${cap.identifierHint ? `. ${cap.identifierHint}` : ""}`);
    }
    if (m.amountMode === "fixed" && !m.fixedAmountCents) bad("fixedAmountCents", "Enter the fixed amount");
  });
export type PaymentMethodInput = z.infer<typeof PaymentMethodInput>;

export function qrAllowed(provider: ProviderId): boolean {
  return PROVIDER_CAPABILITIES[provider].supportsQr;
}

/** An enabled method must give applicants at least one way to pay. */
export function hasPayableDetails(m: { paymentUrl?: string; identifier?: string; hasQr?: boolean }): boolean {
  return Boolean(m.paymentUrl || m.identifier || m.hasQr);
}

export interface StoredMethod extends PaymentMethodInput {
  id: string;
  hasQr: boolean;
  qrPath?: string | null;
  qrContentType?: string | null;
}

export function methodAvailableIn(m: Pick<StoredMethod, "countries">, country: string | undefined): boolean {
  if (!m.countries.length) return true;
  return Boolean(country) && m.countries.includes(country!.toUpperCase());
}
