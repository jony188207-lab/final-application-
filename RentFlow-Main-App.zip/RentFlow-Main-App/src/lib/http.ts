import { z } from "zod";

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

/** Validate untrusted input. Throws a 400 with a short, non-leaky message. */
export function parseInput<S extends z.ZodTypeAny>(schema: S, data: unknown): z.infer<S> {
  const r = schema.safeParse(data);
  if (!r.success) {
    const first = r.error.issues[0];
    throw new HttpError(400, `Invalid input${first ? `: ${first.path.join(".") || "body"} ${first.message}` : ""}`);
  }
  return r.data;
}

export async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new HttpError(400, "Invalid JSON body");
  }
}

export function queryParams(req: Request): Record<string, string> {
  return Object.fromEntries(new URL(req.url).searchParams);
}
