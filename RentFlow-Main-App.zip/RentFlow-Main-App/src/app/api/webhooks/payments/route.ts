import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { WebhookEvent, applyEvent, verifyWebhookSignature } from "@/lib/payments/webhook";
import { writeAudit } from "@/lib/audit";
import { createNotification } from "@/lib/notify";

export const dynamic = "force-dynamic";

// Provider → server webhook. The ONLY path that can mark a payment as paid without an admin
// pressing "verify". Unsigned, stale, or malformed requests are rejected before any data access.
export async function POST(req: Request) {
  const secret = process.env.PAYMENT_WEBHOOK_SECRET ?? "";
  const raw = await req.text();
  if (!verifyWebhookSignature(raw, req.headers.get("x-rentflow-signature"), secret)) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }
  let event;
  try {
    event = WebhookEvent.parse(JSON.parse(raw));
  } catch {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const db = adminDb();
  try {
    // Idempotency: create() fails if this event id was already processed.
    await db.collection("webhookEvents").doc(event.id).create({ at: FieldValue.serverTimestamp(), type: event.type });
  } catch {
    return NextResponse.json({ ok: true, duplicate: true });
  }

  const found = await db.collection("payments").where("providerRef", "==", event.data.providerRef).limit(1).get();
  const doc = found.docs[0];
  if (!doc) return NextResponse.json({ ok: true, unmatched: true });

  const pay = doc.data();
  const { status, amountMismatch } = applyEvent(event, pay.amountCents);
  await doc.ref.update({
    status,
    needsReview: amountMismatch,
    cardBrand: event.data.cardBrand ?? pay.cardBrand ?? null,
    cardLast4: event.data.cardLast4 ?? pay.cardLast4 ?? null,
    updatedAt: FieldValue.serverTimestamp(),
  });
  await doc.ref.collection("events").add({ at: FieldValue.serverTimestamp(), source: "webhook", eventId: event.id, status, mismatch: amountMismatch });
  await writeAudit({
    actorUid: "system:webhook", action: "payment.status_changed", targetType: "payment", targetId: doc.id,
    meta: { from: pay.status, to: status, amountMismatch },
  });

  if (amountMismatch) await createNotification({ type: "system.error", title: "Payment amount mismatch", message: `Payment ${doc.id} amount differs from the provider event.`, link: "/admin/payments" });
  else if (status === "succeeded") await createNotification({ type: "payment.completed", title: "Payment completed", message: `Payment ${doc.id} completed.`, link: "/admin/payments" });
  else if (status === "failed") await createNotification({ type: "payment.failed", title: "Payment failed", message: `Payment ${doc.id} failed.`, link: "/admin/payments" });

  return NextResponse.json({ ok: true });
}
