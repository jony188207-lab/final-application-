import { loadMethod } from "@/lib/checkout";
import { readPrivate } from "@/lib/storage";

export const dynamic = "force-dynamic";

// QR images are meant for applicants, but they stay in the PRIVATE bucket and are streamed only for
// methods that are currently enabled.
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const m = await loadMethod(params.id);
    if (!m || !m.enabled || !m.hasQr || !m.qrPath) return new Response("Not found", { status: 404 });
    const buf = await readPrivate(m.qrPath);
    return new Response(new Uint8Array(buf), {
      headers: {
        "content-type": m.qrContentType ?? "image/png",
        "cache-control": "public, max-age=300",
        "x-content-type-options": "nosniff",
        "content-security-policy": "default-src 'none'",
      },
    });
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
