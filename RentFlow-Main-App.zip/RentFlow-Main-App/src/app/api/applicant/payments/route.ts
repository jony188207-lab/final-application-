import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { adminDb } from "@/lib/firebase/admin";
import { errorResponse } from "@/lib/auth/admin-guard";
import { requireApplicant } from "@/lib/auth/applicant-guard";
import { writeAudit } from "@/lib/audit";
import { getAppSettings } from "@/lib/config";
import { loadMethod, loadPromo, quoteForMethod } from "@/lib/checkout";
import { methodAvailableIn } from "@/lib/paymentMethods";
import { readImageUpload } from "@/lib/files";
import { HttpError, parseInput } from "@/lib/http";
import { createNotification } from "@/lib/notify";
import { rateLimit } from "@/lib/ratelimit";
import { deletePrivate, putPrivate } from "@/lib/storage";

export const dynamic = "force-dynamic";

const Fields = z.object({
  methodId: z.string().min(1).max(100),
  transactionRef: z.string().trim().min(4, "Enter the transaction reference").max(100),
  idempotencyKey: z.string().regex(/^[A-Za-z0-9_-]{16,64}$/),
  country: z.string().regex(/^[A-Za-z]{2}$/).optional(),
  promo: z.string().max(40).optional(),
});

/**
 * Applicant submits payment PROOF (transaction reference + screenshot). This creates a payment in
 * `pending_verification`. It is never "paid": only an admin (or an authenticated provider webhook)
 * can verify it. Any amount/status sent by the browser is ignored; the amount is computed here.
 */
export async function POST(req: Request) {
  try {
    const a = await requireApplicant(req);
    await rateLimit("payment-proof", a.uid, 10, 3600);
    const form = await req.formData().catch(() => null);
    if (!form) throw new HttpError(400, "Invalid form data");
    const f = parseInput(Fields, {
      methodId: form.get("methodId"),
      transactionRef: form.get("transactionRef"),
      idempotencyKey: form.get("idempotencyKey"),
      country: form.get("country") || undefined,
      promo: form.get("promo") || undefined,
    });

    const db = adminDb();
    const paymentId = `${a.uid}_${f.idempotencyKey}`;
    const payRef = db.collection("payments").doc(paymentId);

    // Duplicate-submission protection #1: the same idempotency key returns the same payment.
    const existing = await payRef.get();
    if (existing.exists) return NextResponse.json({ paymentId, duplicate: true });

    const settings = await getAppSettings();
    if (!settings.applicationsEnabled) throw new HttpError(403, "New applications are currently closed");

    const method = await loadMethod(f.methodId);
    if (!method || !method.enabled) throw new HttpError(400, "That payment method is not available");
    if (!methodAvailableIn(method, f.country)) throw new HttpError(400, "That payment method is not available in your country");

    const promo = await loadPromo(f.promo);
    if (f.promo && !promo) throw new HttpError(400, "This promo code is not valid");
    const quote = quoteForMethod(method, settings, promo, Date.now());
    if (!quote.ok) throw new HttpError(400, quote.reason);

    const image = await readImageUpload(form.get("screenshot"));
    if (!image && settings.requireScreenshot) throw new HttpError(400, "A payment screenshot is required");

    // Duplicate-submission protection #2: one transaction reference can be used once per method.
    const refKey = createHash("sha256").update(`${method.id}:${f.transactionRef.toLowerCase()}`).digest("hex");
    const refDoc = db.collection("paymentRefs").doc(refKey);
    try {
      await refDoc.create({ paymentId, uid: a.uid, createdAt: FieldValue.serverTimestamp() });
    } catch {
      throw new HttpError(409, "This transaction reference has already been submitted");
    }

    let proofPath: string | null = null;
    try {
      if (image) {
        proofPath = `payment-proofs/${a.uid}/${paymentId}.${image.ext}`;
        await putPrivate(proofPath, image.buf, image.mime);
      }
      await payRef.create({
        source: "manual",
        applicantUid: a.uid,
        applicantEmail: a.email,
        methodId: method.id,
        methodProvider: method.provider,
        methodName: method.displayName,
        provider: `manual:${method.provider}`,
        providerRef: null,
        transactionRef: f.transactionRef,
        proofPath,
        proofContentType: image?.mime ?? null,
        amountCents: quote.amountCents, // server-computed price snapshot; later fee changes never alter it
        currency: quote.currency,
        baseCents: quote.baseCents,
        discountCents: quote.discountCents,
        promoCode: quote.promoCode,
        status: "pending_verification",
        refundStatus: "none",
        needsReview: false,
        applicationId: null,
        isSample: false,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
    } catch (e) {
      await refDoc.delete().catch(() => undefined);
      if (proofPath) await deletePrivate(proofPath).catch(() => undefined);
      throw e;
    }
    await payRef.collection("events").add({ at: FieldValue.serverTimestamp(), source: `applicant:${a.uid}`, status: "pending_verification" });
    if (quote.promoCode) await db.collection("promoCodes").doc(quote.promoCode).update({ usedCount: FieldValue.increment(1) }).catch(() => undefined);

    await writeAudit({ actorUid: a.uid, actorEmail: a.email, action: "payment.proof_submitted", targetType: "payment", targetId: paymentId, meta: { method: method.provider, amountCents: quote.amountCents, hasScreenshot: Boolean(image) }, ip: a.ip });
    await createNotification({ type: "payment.proof_submitted", title: "Payment proof submitted", message: `Payment ${paymentId} awaits verification.`, link: "/admin/payments" });

    return NextResponse.json({ paymentId, amountCents: quote.amountCents, currency: quote.currency, status: "Submitted" }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
