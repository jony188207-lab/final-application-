export const metadata = { title: "Contact" };

export default function Contact() {
  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold">Contact us</h1>
      <p className="mt-3 text-sm text-slate-600">
        Questions about your application, a data request, or a dispute? Send us a message. Please do not include your
        Social Security number, card numbers, or other sensitive details in this form.
      </p>
      <form className="card mt-6 space-y-4" action="/api/contact" method="post">
        <div>
          <label className="label" htmlFor="name">Name</label>
          <input id="name" name="name" required maxLength={100} className="input" />
        </div>
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" name="email" type="email" required maxLength={200} className="input" />
        </div>
        <div>
          <label className="label" htmlFor="message">Message</label>
          <textarea id="message" name="message" required maxLength={2000} rows={5} className="input" />
        </div>
        <button className="btn-primary" type="submit">Send message</button>
      </form>
    </div>
  );
}
