"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, sendEmailVerification, signInWithEmailAndPassword, signOut, type User,
} from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";
import { ApplicationInput } from "@/lib/applicationSchema";

const money = (cents: number | null | undefined, cur = "USD") =>
  cents == null ? "—" : new Intl.NumberFormat("en-US", { style: "currency", currency: cur.toUpperCase() }).format(cents / 100);

type Method = {
  id: string; provider: string; displayName: string; description: string; instructions: string; applicantGuidance: string;
  paymentUrl: string | null; identifier: string | null; hasQr: boolean; amountCents: number | null; currency: string; discountCents: number;
};

export default function ApplyPage() {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  useEffect(() => onAuthStateChanged(firebaseAuth(), setUser), []);

  const call = useCallback(
    async (path: string, init: { method?: string; body?: any; form?: FormData } = {}) => {
      const token = await firebaseAuth().currentUser?.getIdToken();
      const res = await fetch(path, {
        method: init.method ?? "GET",
        headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...(init.body ? { "content-type": "application/json" } : {}) },
        body: init.form ?? (init.body ? JSON.stringify(init.body) : undefined),
      });
      return { ok: res.ok, status: res.status, data: await res.json().catch(() => ({})) };
    },
    [],
  );

  if (user === undefined) return <p role="status">Loading…</p>;
  if (!user) return <AuthPanel />;
  if (!user.emailVerified) return <VerifyPanel user={user} />;
  return <Wizard user={user} call={call} />;
}

/* ---------- registration / login ---------- */
function AuthPanel() {
  const [mode, setMode] = useState<"login" | "register">("register");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr(null); setBusy(true);
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email")), password = String(f.get("password"));
    try {
      if (mode === "register") {
        if (password.length < 8) throw new Error("Password must be at least 8 characters");
        const cred = await createUserWithEmailAndPassword(firebaseAuth(), email, password);
        await sendEmailVerification(cred.user);
      } else {
        await signInWithEmailAndPassword(firebaseAuth(), email, password);
      }
    } catch (e: any) {
      setErr(e?.message?.startsWith("Password") ? e.message : mode === "login" ? "Sign-in failed. Check your email and password." : "Could not create the account. The email may already be registered.");
    }
    setBusy(false);
  }

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="text-2xl font-bold">Rental application</h1>
      <p className="mt-2 text-sm text-slate-600">Create an account to apply, pay the fee and track your application.</p>
      <div className="mt-4 flex gap-2" role="tablist">
        {(["register", "login"] as const).map((m) => (
          <button key={m} role="tab" aria-selected={mode === m} onClick={() => setMode(m)} className={`btn flex-1 ${mode === m ? "bg-brand-600 text-white" : "border border-slate-300 bg-white"}`}>{m === "register" ? "Create account" : "Sign in"}</button>
        ))}
      </div>
      <form onSubmit={submit} className="card mt-4 space-y-4">
        <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="email" required className="input" /></div>
        <div><label className="label" htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} required minLength={8} className="input" /></div>
        {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? "Please wait…" : mode === "register" ? "Create account" : "Sign in"}</button>
      </form>
    </div>
  );
}

function VerifyPanel({ user }: { user: User }) {
  const [msg, setMsg] = useState<string | null>(null);
  return (
    <div className="mx-auto max-w-md card space-y-3">
      <h1 className="text-xl font-bold">Verify your email</h1>
      <p className="text-sm text-slate-600">We sent a verification link to <strong>{user.email}</strong>. Open it, then continue.</p>
      {msg && <p role="status" className="text-sm">{msg}</p>}
      <div className="flex flex-wrap gap-2">
        <button className="btn-primary" onClick={async () => { await user.reload(); await user.getIdToken(true); if (!firebaseAuth().currentUser?.emailVerified) setMsg("Not verified yet."); else window.location.reload(); }}>I've verified</button>
        <button className="btn-secondary" onClick={async () => { try { await sendEmailVerification(user); setMsg("Verification email sent again."); } catch { setMsg("Please wait a moment before requesting another email."); } }}>Resend email</button>
        <button className="btn-secondary" onClick={() => signOut(firebaseAuth())}>Sign out</button>
      </div>
    </div>
  );
}

/* ---------- wizard: pay → proof → application ---------- */
type Call = (path: string, init?: { method?: string; body?: any; form?: FormData }) => Promise<{ ok: boolean; status: number; data: any }>;

function Wizard({ user, call }: { user: User; call: Call }) {
  const [mine, setMine] = useState<any>(null);
  const [paymentId, setPaymentId] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  const loadMine = useCallback(async () => { const r = await call("/api/applicant/applications"); if (r.ok) setMine(r.data); }, [call]);
  useEffect(() => { loadMine(); }, [loadMine]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-bold">Rental application</h1>
        <button className="btn-secondary" onClick={() => signOut(firebaseAuth())}>Sign out ({user.email})</button>
      </div>

      {mine?.applications?.length > 0 && (
        <section className="card" aria-label="Your applications">
          <h2 className="font-semibold">Your applications</h2>
          <ul className="mt-2 divide-y text-sm">
            {mine.applications.map((a: any) => (
              <li key={a.reference} className="flex flex-wrap justify-between gap-2 py-2">
                <span><strong>{a.reference}</strong> · {a.applicationStatus.replace(/_/g, " ")}</span>
                <span>Payment: <strong>{a.payment?.label ?? "—"}</strong></span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {done ? (
        <section className="card border-green-300 bg-green-50" role="status">
          <h2 className="text-lg font-bold text-green-900">Application submitted</h2>
          <p className="mt-1 text-sm">Your reference number is <strong className="text-xl">{done}</strong>. Keep it to check your status. Your payment is pending verification; a person will confirm it.</p>
          <button className="btn-secondary mt-3" onClick={() => { setDone(null); setPaymentId(null); loadMine(); }}>Start another application</button>
        </section>
      ) : !paymentId ? (
        <>
          {mine?.unlinkedPayments?.length > 0 && (
            <section className="card">
              <h2 className="font-semibold">Continue with a submitted payment</h2>
              <ul className="mt-2 space-y-2 text-sm">
                {mine.unlinkedPayments.map((p: any) => (
                  <li key={p.paymentId} className="flex flex-wrap items-center justify-between gap-2">
                    <span>{p.methodName} · {money(p.amountCents, p.currency)} · <strong>{p.label}</strong></span>
                    <button className="btn-secondary" onClick={() => setPaymentId(p.paymentId)}>Fill in application</button>
                  </li>
                ))}
              </ul>
            </section>
          )}
          <PaymentStep call={call} onSubmitted={(id) => setPaymentId(id)} />
        </>
      ) : (
        <ApplicationForm call={call} paymentId={paymentId} onDone={(ref) => setDone(ref)} />
      )}
    </div>
  );
}

function PaymentStep({ call, onSubmitted }: { call: Call; onSubmitted: (paymentId: string) => void }) {
  const [country, setCountry] = useState("US");
  const [promo, setPromo] = useState("");
  const [appliedPromo, setAppliedPromo] = useState("");
  const [checkout, setCheckout] = useState<any>(null);
  const [loadErr, setLoadErr] = useState<string | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [ref, setRef] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const idem = useRef<string>(typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().replace(/-/g, "") : String(Date.now()) + Math.random().toString(36).slice(2, 12));

  useEffect(() => {
    const qs = new URLSearchParams({ country });
    if (appliedPromo) qs.set("promo", appliedPromo);
    fetch(`/api/public/checkout?${qs}`).then(async (r) => {
      const d = await r.json().catch(() => ({}));
      if (!r.ok) return setLoadErr(d.error ?? "Could not load payment options");
      setLoadErr(null); setCheckout(d);
      setSel((cur) => (d.methods.some((m: Method) => m.id === cur) ? cur : null));
    }).catch(() => setLoadErr("Could not load payment options"));
  }, [country, appliedPromo]);

  if (loadErr) return <p role="alert" className="text-red-700">{loadErr}</p>;
  if (!checkout) return <p role="status">Loading payment options…</p>;
  if (!checkout.applicationsEnabled) return <div className="card">New applications are currently closed. Please check back later.</div>;

  const method: Method | undefined = checkout.methods.find((m: Method) => m.id === sel);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!method) return;
    setErr(null);
    if (ref.trim().length < 4) return setErr("Enter the transaction reference from your payment");
    if (checkout.requireScreenshot && !file) return setErr("Upload a screenshot of your payment");
    if (file && file.size > 4 * 1024 * 1024) return setErr("Screenshot must be 4 MB or smaller");
    setBusy(true);
    const fd = new FormData();
    fd.append("methodId", method.id); fd.append("transactionRef", ref.trim()); fd.append("idempotencyKey", idem.current); fd.append("country", country);
    if (appliedPromo) fd.append("promo", appliedPromo);
    if (file) fd.append("screenshot", file);
    const r = await call("/api/applicant/payments", { method: "POST", form: fd });
    setBusy(false);
    if (!r.ok) return setErr(r.data.error ?? "Could not submit your payment proof");
    onSubmitted(r.data.paymentId);
  }

  return (
    <section className="space-y-4" aria-label="Application fee and payment">
      <div className="card">
        <h2 className="font-semibold">1. Application fee</h2>
        <p className="mt-1 text-3xl font-bold">{money(checkout.baseCents, checkout.baseCurrency)}</p>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <div><label className="label" htmlFor="country">Your country (ISO code)</label><input id="country" className="input" maxLength={2} value={country} onChange={(e) => setCountry(e.target.value.toUpperCase())} /></div>
          <div className="sm:col-span-2"><label className="label" htmlFor="promo">Promo code (optional)</label>
            <div className="flex gap-2"><input id="promo" className="input" value={promo} onChange={(e) => setPromo(e.target.value.toUpperCase())} /><button type="button" className="btn-secondary" onClick={() => setAppliedPromo(promo.trim())}>Apply</button></div>
            {checkout.promo && <p className={`mt-1 text-xs ${checkout.promo.valid ? "text-green-700" : "text-red-700"}`}>{checkout.promo.valid ? `Promo ${checkout.promo.code} applied` : checkout.promo.reason}</p>}
          </div>
        </div>
      </div>

      <div className="card">
        <h2 className="font-semibold">2. Choose how to pay</h2>
        {checkout.methods.length === 0 ? <p className="mt-2 text-sm text-slate-600">No payment methods are available for your country right now.</p> : (
          <div className="mt-2 space-y-2" role="radiogroup" aria-label="Payment method">
            {checkout.methods.map((m: Method) => (
              <label key={m.id} className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 ${sel === m.id ? "border-brand-500 bg-brand-50" : "border-slate-200"}`}>
                <input type="radio" name="method" className="mt-1" checked={sel === m.id} onChange={() => setSel(m.id)} />
                <span className="flex-1"><strong>{m.displayName}</strong> <span className="text-sm text-slate-600">· {money(m.amountCents, m.currency)}</span>{m.description && <span className="block text-sm text-slate-600">{m.description}</span>}</span>
              </label>
            ))}
          </div>
        )}
      </div>

      {method && (
        <form onSubmit={submit} className="card space-y-4">
          <h2 className="font-semibold">3. Pay {money(method.amountCents, method.currency)} with {method.displayName}</h2>
          <div className="space-y-2 text-sm">
            {method.instructions && <p className="whitespace-pre-line">{method.instructions}</p>}
            {method.paymentUrl && <p><a className="btn-primary" href={method.paymentUrl} target="_blank" rel="noopener noreferrer">Open payment page</a></p>}
            {method.identifier && <p>Send to: <code className="rounded bg-slate-100 px-2 py-1 font-semibold">{method.identifier}</code></p>}
            {method.hasQr && <img src={`/api/public/payment-methods/${method.id}/qr`} alt={`${method.displayName} payment QR code`} className="h-48 w-48 rounded border" />}
            {method.applicantGuidance && <p className="rounded bg-amber-50 p-2 text-amber-900">{method.applicantGuidance}</p>}
            <p className="text-xs text-slate-500">Only pay to the details shown on this page. After paying, enter your transaction reference and upload a screenshot below. Your payment is confirmed only after our team verifies it.</p>
          </div>
          <div><label className="label" htmlFor="ref">Transaction reference / ID</label><input id="ref" className="input" maxLength={100} required value={ref} onChange={(e) => setRef(e.target.value)} /></div>
          <div><label className="label" htmlFor="shot">Payment screenshot {checkout.requireScreenshot ? "(required)" : "(optional)"} — PNG, JPEG or WebP, up to 4 MB</label>
            <input id="shot" type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></div>
          {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
          <button className="btn-primary" disabled={busy}>{busy ? "Uploading…" : "Submit payment proof"}</button>
        </form>
      )}
    </section>
  );
}

function ApplicationForm({ call, paymentId, onDone }: { call: Call; paymentId: string; onDone: (ref: string) => void }) {
  const [errs, setErrs] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [pets, setPets] = useState<{ type: string; breed: string }[]>([]);
  const [history, setHistory] = useState<{ address: string; landlord: string; from: string; to: string; rent: string; reason: string }[]>([{ address: "", landlord: "", from: "", to: "", rent: "", reason: "" }]);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const s = (k: string) => String(f.get(k) ?? "");
    const cents = (v: string) => Math.round(Number(v) * 100);
    const candidate = {
      paymentId,
      fullName: s("fullName"), phone: s("phone"),
      property: { address: s("address"), rentCents: cents(s("rent")), moveIn: s("moveIn") },
      household: { adults: Number(s("adults")), children: Number(s("children")), pets: pets.filter((p) => p.type.trim()).map((p) => ({ type: p.type, breed: p.breed })) },
      employment: { employer: s("employer"), title: s("title"), monthlyIncomeCents: cents(s("income")), startDate: s("startDate") },
      rentalHistory: history.filter((h) => h.address.trim()).map((h) => ({ address: h.address, landlord: h.landlord, from: h.from, to: h.to, rentCents: h.rent ? cents(h.rent) : undefined, reason: h.reason })),
      ssn: s("ssn"),
      consent: { fcraDisclosure: f.get("c1") === "on", screeningAuthorization: f.get("c2") === "on" },
    };
    const parsed = ApplicationInput.safeParse(candidate);
    if (!parsed.success) return setErrs(parsed.error.issues.map((i) => `${i.path.join(".") || "form"}: ${i.message}`));
    setErrs([]); setBusy(true);
    const r = await call("/api/applicant/applications", { method: "POST", body: parsed.data });
    setBusy(false);
    if (!r.ok) return setErrs([r.data.error ?? "Could not submit your application"]);
    onDone(r.data.reference);
  }

  const L = ({ id, children }: { id: string; children: React.ReactNode }) => <label className="label" htmlFor={id}>{children}</label>;
  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <div className="rounded-lg border border-green-200 bg-green-50 p-3 text-sm">Payment proof received. It stays <strong>pending verification</strong> until our team confirms it. Now complete your application.</div>
      {errs.length > 0 && <ul role="alert" className="list-disc rounded-lg border border-red-200 bg-red-50 p-3 pl-6 text-sm text-red-800">{errs.map((x, i) => <li key={i}>{x}</li>)}</ul>}

      <fieldset className="card grid gap-3 sm:grid-cols-2"><legend className="px-1 font-semibold">About you</legend>
        <div><L id="fullName">Full legal name</L><input id="fullName" name="fullName" className="input" required /></div>
        <div><L id="phone">Phone</L><input id="phone" name="phone" type="tel" className="input" required /></div>
      </fieldset>
      <fieldset className="card grid gap-3 sm:grid-cols-3"><legend className="px-1 font-semibold">Rental property</legend>
        <div className="sm:col-span-3"><L id="address">Property address</L><input id="address" name="address" className="input" required /></div>
        <div><L id="rent">Monthly rent (USD)</L><input id="rent" name="rent" inputMode="decimal" className="input" required /></div>
        <div><L id="moveIn">Desired move-in</L><input id="moveIn" name="moveIn" type="date" className="input" required /></div>
      </fieldset>
      <fieldset className="card grid gap-3 sm:grid-cols-2"><legend className="px-1 font-semibold">Household & pets</legend>
        <div><L id="adults">Adults</L><input id="adults" name="adults" type="number" min={1} max={10} defaultValue={1} className="input" /></div>
        <div><L id="children">Children</L><input id="children" name="children" type="number" min={0} max={10} defaultValue={0} className="input" /></div>
        <div className="sm:col-span-2 space-y-2">
          {pets.map((p, i) => (
            <div key={i} className="flex gap-2"><input aria-label="Pet type" className="input" placeholder="Type (dog, cat…)" value={p.type} onChange={(e) => setPets(pets.map((x, j) => j === i ? { ...x, type: e.target.value } : x))} /><input aria-label="Breed" className="input" placeholder="Breed (optional)" value={p.breed} onChange={(e) => setPets(pets.map((x, j) => j === i ? { ...x, breed: e.target.value } : x))} /><button type="button" className="btn-secondary" onClick={() => setPets(pets.filter((_, j) => j !== i))}>Remove</button></div>
          ))}
          {pets.length < 5 && <button type="button" className="btn-secondary" onClick={() => setPets([...pets, { type: "", breed: "" }])}>Add a pet</button>}
        </div>
      </fieldset>
      <fieldset className="card grid gap-3 sm:grid-cols-2"><legend className="px-1 font-semibold">Employment & income</legend>
        <div><L id="employer">Employer</L><input id="employer" name="employer" className="input" required /></div>
        <div><L id="title">Job title</L><input id="title" name="title" className="input" required /></div>
        <div><L id="income">Monthly income before tax (USD)</L><input id="income" name="income" inputMode="decimal" className="input" required /></div>
        <div><L id="startDate">Start date (YYYY-MM)</L><input id="startDate" name="startDate" placeholder="2022-03" className="input" /></div>
      </fieldset>
      <fieldset className="card space-y-3"><legend className="px-1 font-semibold">Rental history</legend>
        {history.map((h, i) => (
          <div key={i} className="grid gap-2 sm:grid-cols-3">
            {(["address", "landlord", "from", "to", "rent", "reason"] as const).map((k) => (
              <input key={k} aria-label={`Previous rental ${k}`} className="input" placeholder={{ address: "Address", landlord: "Landlord", from: "From (YYYY-MM)", to: "To (YYYY-MM)", rent: "Rent (USD)", reason: "Reason for leaving" }[k]} value={h[k]} onChange={(e) => setHistory(history.map((x, j) => j === i ? { ...x, [k]: e.target.value } : x))} />
            ))}
          </div>
        ))}
        {history.length < 5 && <button type="button" className="btn-secondary" onClick={() => setHistory([...history, { address: "", landlord: "", from: "", to: "", rent: "", reason: "" }])}>Add another address</button>}
      </fieldset>
      <fieldset className="card space-y-2"><legend className="px-1 font-semibold">Identity (optional)</legend>
        <p className="text-sm text-slate-600">Provide your Social Security number only if the screening provider requires it. It is stored encrypted and shown only to specifically authorized staff.</p>
        <input aria-label="Social Security number" name="ssn" inputMode="numeric" autoComplete="off" placeholder="Optional" className="input sm:w-60" />
      </fieldset>
      <fieldset className="card space-y-2"><legend className="px-1 font-semibold">Disclosure & authorization</legend>
        <p className="text-sm text-slate-600">A consumer report may be obtained about you from a consumer reporting agency to evaluate this application. If a decision is based in whole or in part on that report, you will be told which agency provided it, and you have the right to a free copy and to dispute inaccurate information.</p>
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="c1" className="mt-1" /> I have read the disclosure that a consumer report may be obtained for rental screening, and I have reviewed the <a className="underline" href="/applicant-rights" target="_blank">Applicant Rights</a> and <a className="underline" href="/privacy" target="_blank">Privacy Policy</a>.</label>
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="c2" className="mt-1" /> I authorize a tenant-screening report to be obtained about me for evaluating this rental application.</label>
      </fieldset>
      <button className="btn-primary" disabled={busy}>{busy ? "Submitting…" : "Submit application"}</button>
    </form>
  );
}
